a = 24.345
print (f"{a:03.0f}")